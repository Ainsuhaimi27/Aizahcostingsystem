# aizahcostingsystem - titik pulang modal

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ainsuhaimi27/pen/qBevPvV](https://codepen.io/Ainsuhaimi27/pen/qBevPvV).

