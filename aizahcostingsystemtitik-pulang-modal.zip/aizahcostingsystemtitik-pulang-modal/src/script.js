document
  .getElementById("calculator-form")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // Mencegah borang daripada dihantar secara default

    // Ambil nilai daripada input
    var totalCost = parseFloat(document.getElementById("total-cost").value);
    var variableCost = parseFloat(
      document.getElementById("variable-cost").value
    );
    var unitPrice = parseFloat(document.getElementById("unit-price").value);
    var unitsSold = parseFloat(document.getElementById("units-sold").value);

    // Semak jika semua input adalah nombor yang sah
    if (
      isNaN(totalCost) ||
      isNaN(variableCost) ||
      isNaN(unitPrice) ||
      isNaN(unitsSold)
    ) {
      alert("Sila masukkan nilai yang sah untuk semua medan.");
      return;
    }

    // Kira Kos Tetap (Kos Tetap = Jumlah Kos - Kos Berubah)
    var fixedCost = totalCost - variableCost;

    // Kira Kos Berubah Seunit
    var variableCostPerUnit = variableCost / unitsSold;

    // Kira Margin Caruman Seunit (Margin Caruman Seunit = Harga Jualan - Kos Berubah Seunit)
    var contributionMarginPerUnit = unitPrice - variableCostPerUnit;

    // Kira Kos Seunit (Kos Seunit = Jumlah Kos / Jumlah Unit Terjual)
    var costPerUnit = totalCost / unitsSold;

    // Kira Titik Pulang Modal (Unit)
    var breakEvenPointUnits = fixedCost / contributionMarginPerUnit;

    // Kira Titik Pulang Modal (RM)
    var breakEvenPointRM = breakEvenPointUnits * unitPrice;

    // Paparkan hasil pengiraan
    var resultText = `
        <strong>Kos Tetap:</strong> RM ${fixedCost.toFixed(2)} <br>
        <strong>Kos Berubah Seunit:</strong> RM ${variableCostPerUnit.toFixed(
          2
        )} <br>
        <strong>Margin Caruman Seunit:</strong> RM ${contributionMarginPerUnit.toFixed(
          2
        )} <br>
        <strong>Kos Seunit:</strong> RM ${costPerUnit.toFixed(2)} <br>
        <strong>Titik Pulang Modal (Unit):</strong> ${breakEvenPointUnits.toFixed(
          2
        )} unit <br>
        <strong>Titik Pulang Modal (RM):</strong> RM ${breakEvenPointRM.toFixed(
          2
        )}
    `;
    document.getElementById("result-text").innerHTML = resultText;
    document.getElementById("result").style.display = "block"; // Tunjukkan hasil
  });
